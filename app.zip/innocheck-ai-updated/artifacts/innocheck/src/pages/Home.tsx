import { useState } from "react";
import { useAnalyzeIdea } from "@workspace/api-client-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Lightbulb, 
  Zap,
  ArrowRight,
  RefreshCw,
  Brain,
  Star,
  Shield,
  ClipboardList,
  PenLine,
  Search,
  BarChart2,
  Rocket,
  GraduationCap,
  Building2,
  Briefcase,
  Network
} from "lucide-react";
import { ScoreRing } from "@/components/ScoreRing";
import { cn } from "@/lib/utils";

export default function Home() {
  const [idea, setIdea] = useState("");
  const { mutate, isPending, data, isError, error } = useAnalyzeIdea();

  const handleAnalyze = () => {
    if (!idea.trim()) return;
    mutate({ data: { idea } });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleAnalyze();
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-background text-foreground selection:bg-primary/30 selection:text-primary-foreground overflow-hidden font-sans">
      {/* Background with animated orbs */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-[#040914]" />
        
        {/* Animated Orbs */}
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-primary/20 blur-[120px]" 
        />
        <motion.div 
          animate={{ 
            scale: [1, 1.5, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-[-20%] right-[-10%] w-[60vw] h-[60vw] rounded-full bg-accent/20 blur-[150px]" 
        />
      </div>

      {/* 1) NAVBAR */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-background/60 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xl font-display font-bold cursor-pointer" onClick={() => window.scrollTo({top:0, behavior:'smooth'})}>
            <div className="p-1.5 rounded-md bg-gradient-to-br from-primary to-accent text-white">
              <Sparkles className="w-5 h-5" />
            </div>
            <span>InnoCheck <span className="text-white/70 font-normal">Enterprise</span></span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-white/70">
            <button onClick={() => scrollToSection('features')} className="hover:text-white transition-colors">Features</button>
            <button onClick={() => scrollToSection('how-it-works')} className="hover:text-white transition-colors">How It Works</button>
            <button onClick={() => scrollToSection('demo')} className="hover:text-white transition-colors">Demo</button>
            <button onClick={() => scrollToSection('impact')} className="hover:text-white transition-colors">Contact</button>
          </div>
          
          <div>
            <button 
              onClick={() => scrollToSection('demo')}
              className="px-5 py-2 rounded-full bg-white text-black font-semibold text-sm hover:bg-white/90 transition-colors shadow-[0_0_15px_rgba(255,255,255,0.3)] hover:shadow-[0_0_25px_rgba(255,255,255,0.5)]"
            >
              Try Now
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="relative z-10 pt-24 pb-12">
        
        {/* 2) HERO SECTION */}
        <section className="min-h-[85vh] flex flex-col items-center justify-center px-4 pt-10 pb-20 max-w-7xl mx-auto relative">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center max-w-4xl mx-auto relative z-10"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm font-medium mb-8 text-primary backdrop-blur-md">
              <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
              Enterprise Grade Idea Validation
            </div>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold font-display mb-8 leading-[1.1] tracking-tight">
              AI that validates your idea <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-blue-400 to-accent">before you build it</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/60 mb-10 max-w-2xl mx-auto font-light leading-relaxed">
              InnoCheck Enterprise uses a multi-agent AI workflow to analyze, score, and improve innovation ideas in seconds.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={() => scrollToSection('demo')}
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-primary text-primary-foreground font-semibold text-lg hover:bg-primary/90 transition-all shadow-[0_0_30px_rgba(0,183,255,0.4)] hover:shadow-[0_0_40px_rgba(0,183,255,0.6)] hover:-translate-y-1 flex items-center justify-center gap-2"
              >
                Try Live Demo
                <ArrowRight className="w-5 h-5" />
              </button>
              <button 
                onClick={() => scrollToSection('how-it-works')}
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-white/5 border border-white/10 text-white font-semibold text-lg hover:bg-white/10 transition-all hover:-translate-y-1"
              >
                View Architecture
              </button>
            </div>
          </motion.div>

          {/* Floating Agent Cards */}
          <div className="mt-20 relative w-full max-w-4xl mx-auto h-32 hidden md:block">
            <motion.div 
              animate={{ y: [0, -10, 0] }} 
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute left-[10%] top-0 glass-panel px-4 py-2 rounded-xl flex items-center gap-2 text-sm font-medium border-white/10 shadow-lg backdrop-blur-md"
            >
              <Brain className="w-4 h-4 text-primary" /> Novelty Agent
            </motion.div>
            <motion.div 
              animate={{ y: [0, 15, 0] }} 
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute left-[35%] top-10 glass-panel px-4 py-2 rounded-xl flex items-center gap-2 text-sm font-medium border-white/10 shadow-lg backdrop-blur-md"
            >
              <Shield className="w-4 h-4 text-accent" /> Patent Checker
            </motion.div>
            <motion.div 
              animate={{ y: [0, -15, 0] }} 
              transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              className="absolute right-[35%] top-4 glass-panel px-4 py-2 rounded-xl flex items-center gap-2 text-sm font-medium border-white/10 shadow-lg backdrop-blur-md"
            >
              <Search className="w-4 h-4 text-blue-400" /> Market Scout
            </motion.div>
            <motion.div 
              animate={{ y: [0, 10, 0] }} 
              transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
              className="absolute right-[10%] top-12 glass-panel px-4 py-2 rounded-xl flex items-center gap-2 text-sm font-medium border-white/10 shadow-lg backdrop-blur-md"
            >
              <Zap className="w-4 h-4 text-emerald-400" /> Decision Engine
            </motion.div>
          </div>
        </section>

        {/* 3) HOW IT WORKS */}
        <section id="how-it-works" className="py-24 px-4 relative">
          <div className="max-w-7xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">How It Works</h2>
              <p className="text-white/60 max-w-2xl mx-auto text-lg">Four steps from raw idea to data-driven confidence.</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
              {/* Connecting line for desktop */}
              <div className="hidden md:block absolute top-1/2 left-[10%] right-[10%] h-px bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-y-1/2 z-0" />
              
              {[
                { icon: PenLine, title: "Enter your idea", desc: "Briefly describe your concept, target market, or technology." },
                { icon: Search, title: "AI analyzes market", desc: "Our agents cross-reference patent databases and market trends." },
                { icon: BarChart2, title: "Get novelty score", desc: "Receive an objective 0-100 score on originality." },
                { icon: CheckCircle2, title: "Final decision", desc: "Get a conclusive GO, MODIFY, or REJECT recommendation." }
              ].map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ delay: i * 0.1 }}
                  className="relative z-10 glass-panel p-6 rounded-2xl border border-white/5 hover:border-primary/30 hover:shadow-[0_0_30px_rgba(0,183,255,0.1)] transition-all duration-300 group hover:-translate-y-1 bg-[#0a0f1c]/80"
                >
                  <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-background border border-white/10 flex items-center justify-center text-xs font-bold text-white/50 group-hover:text-primary transition-colors">
                    {i + 1}
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 group-hover:text-primary transition-colors text-white/70">
                    <step.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold mb-2 font-display">{step.title}</h3>
                  <p className="text-sm text-white/50 leading-relaxed">{step.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 4) CORE FEATURES */}
        <section id="features" className="py-24 px-4 bg-white/[0.02] border-y border-white/5">
          <div className="max-w-7xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              className="mb-16"
            >
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Core Features</h2>
              <p className="text-white/60 max-w-2xl text-lg">The enterprise engine powering your validation pipeline.</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: Brain, color: "text-purple-400", bg: "bg-purple-400/10", title: "Multi-Agent Reasoning", desc: "Orchestrated AI agents collaborate to evaluate every dimension of your idea." },
                { icon: Star, color: "text-amber-400", bg: "bg-amber-400/10", title: "Novelty Scoring", desc: "Get a 0–100 score reflecting originality against existing patents and market." },
                { icon: Shield, color: "text-emerald-400", bg: "bg-emerald-400/10", title: "Patent Similarity", desc: "Simulate patent database lookups to catch conflicts before you file." },
                { icon: Zap, color: "text-primary", bg: "bg-primary/10", title: "Instant Decision Engine", desc: "Receive a final GO, MODIFY, or REJECT signal in seconds." },
                { icon: Lightbulb, color: "text-yellow-400", bg: "bg-yellow-400/10", title: "Idea Improvement", desc: "AI rewrites and enhances your concept for maximum market potential." },
                { icon: ClipboardList, color: "text-blue-400", bg: "bg-blue-400/10", title: "Audit Trail", desc: "Full transparency into every agent's reasoning and decision path." }
              ].map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ delay: i * 0.1 }}
                  className="glass-panel p-8 rounded-3xl border border-white/5 hover:border-white/20 transition-all duration-300 group hover:-translate-y-1 relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center mb-6 relative z-10", feature.bg, feature.color)}>
                    <feature.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 font-display relative z-10">{feature.title}</h3>
                  <p className="text-white/60 leading-relaxed relative z-10">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 5) LIVE DEMO SECTION */}
        <section id="demo" className="py-32 px-4 relative">
          <div className="max-w-5xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Try It Live</h2>
              <p className="text-white/60 max-w-2xl mx-auto text-lg">Paste your idea below and watch the agents work.</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="w-full rounded-2xl overflow-hidden glass-panel border border-white/10 shadow-2xl bg-[#030712]/90 backdrop-blur-2xl"
            >
              {/* Browser Chrome */}
              <div className="h-12 bg-white/5 border-b border-white/10 flex items-center px-4">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                </div>
                <div className="mx-auto bg-black/40 border border-white/5 rounded-md px-4 py-1 text-xs text-white/40 font-mono flex items-center gap-2">
                  <span className="text-white/20">https://</span>innocheck.enterprise/analyze
                </div>
                <div className="w-16" /> {/* Spacer for flex balance */}
              </div>

              {/* Demo Content */}
              <div className="p-6 md:p-10">
                <div className="relative group transition-all duration-300">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-primary to-accent rounded-2xl blur opacity-20 group-focus-within:opacity-50 transition duration-500"></div>
                  <div className="relative bg-[#0a0f1c] rounded-xl overflow-hidden border border-white/10">
                    <textarea
                      value={idea}
                      onChange={(e) => setIdea(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Describe your enterprise innovation idea here... (e.g. A B2B platform using LLMs to automatically resolve complex supply chain disruptions)"
                      className="w-full h-48 bg-transparent text-foreground placeholder:text-muted-foreground/50 p-6 resize-none outline-none font-sans text-lg"
                      disabled={isPending}
                    />
                    <div className="flex flex-col sm:flex-row justify-between items-center p-4 bg-white/[0.02] border-t border-white/5 gap-4">
                      <span className="text-xs text-muted-foreground">
                        Press <kbd className="font-mono bg-black/50 border border-white/10 px-1.5 py-0.5 rounded text-white/70 mx-1">Cmd</kbd> + <kbd className="font-mono bg-black/50 border border-white/10 px-1.5 py-0.5 rounded text-white/70 mx-1">Enter</kbd> to analyze
                      </span>
                      <button
                        onClick={handleAnalyze}
                        disabled={isPending || !idea.trim()}
                        className={cn(
                          "w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3 rounded-lg font-semibold transition-all duration-300",
                          "bg-white text-black hover:bg-white/90",
                          "disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100",
                          !isPending && idea.trim() && "hover:scale-105"
                        )}
                      >
                        {isPending ? (
                          <>
                            <RefreshCw className="w-5 h-5 animate-spin" />
                            Agents Validating...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-5 h-5" />
                            Run Enterprise Analysis
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {isError && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }} 
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive flex items-start gap-3"
                  >
                    <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Analysis Failed</h4>
                      <p className="text-sm opacity-90">
                        {(error as any)?.response?.data?.error || "Connection to multi-agent orchestrator failed. Please try again."}
                      </p>
                    </div>
                  </motion.div>
                )}

                <AnimatePresence>
                  {data && !isPending && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0, y: 20 }}
                      animate={{ opacity: 1, height: "auto", y: 0 }}
                      className="mt-10 grid grid-cols-1 md:grid-cols-12 gap-6"
                    >
                      {/* Novelty Score */}
                      <div className="md:col-span-4 bg-[#0a0f1c] border border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        <h3 className="text-sm font-bold uppercase tracking-widest text-white/50 mb-6 self-start w-full">Novelty Score</h3>
                        <ScoreRing score={data.noveltyScore} />
                        <p className="text-sm text-center text-white/60 mt-6 font-medium">
                          {data.noveltyScore >= 80 ? "Highly original. Strong IP potential." : 
                           data.noveltyScore >= 50 ? "Solid, but exists in a competitive landscape." :
                           "Saturated market. Major pivot required."}
                        </p>
                      </div>

                      {/* Improved Idea */}
                      <div className="md:col-span-8 bg-[#0a0f1c] border border-white/10 rounded-2xl p-6 relative overflow-hidden flex flex-col group">
                        <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        <div className="flex items-center gap-3 mb-6 relative z-10">
                          <div className="p-2 rounded-lg bg-accent/20 text-accent">
                            <Lightbulb className="w-5 h-5" />
                          </div>
                          <h3 className="text-xl font-display font-semibold text-white">Agent-Optimized Angle</h3>
                        </div>
                        <div className="relative z-10 flex-grow bg-black/40 border border-white/5 rounded-xl p-5 shadow-inner">
                          <p className="text-base text-white/80 leading-relaxed">
                            {data.improvedIdea}
                          </p>
                        </div>
                      </div>

                      {/* Strengths */}
                      <div className="md:col-span-6 bg-[#0a0f1c] border border-emerald-500/20 rounded-2xl p-6">
                        <div className="flex items-center gap-3 mb-5">
                          <div className="p-1.5 rounded-md bg-emerald-500/20 text-emerald-400">
                            <CheckCircle2 className="w-4 h-4" />
                          </div>
                          <h3 className="text-lg font-display font-semibold text-white">Key Strengths</h3>
                        </div>
                        <ul className="space-y-3">
                          {data.strengths.map((strength, idx) => (
                            <motion.li 
                              initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + (idx * 0.1) }}
                              key={idx} className="flex items-start gap-3 text-white/70 text-sm"
                            >
                              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                              <span>{strength}</span>
                            </motion.li>
                          ))}
                        </ul>
                      </div>

                      {/* Weaknesses */}
                      <div className="md:col-span-6 bg-[#0a0f1c] border border-rose-500/20 rounded-2xl p-6">
                        <div className="flex items-center gap-3 mb-5">
                          <div className="p-1.5 rounded-md bg-rose-500/20 text-rose-400">
                            <AlertTriangle className="w-4 h-4" />
                          </div>
                          <h3 className="text-lg font-display font-semibold text-white">Market Risks</h3>
                        </div>
                        <ul className="space-y-3">
                          {data.weaknesses.map((weakness, idx) => (
                            <motion.li 
                              initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + (idx * 0.1) }}
                              key={idx} className="flex items-start gap-3 text-white/70 text-sm"
                            >
                              <div className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                              <span>{weakness}</span>
                            </motion.li>
                          ))}
                        </ul>
                      </div>

                      {/* Similar Ideas */}
                      <div className="md:col-span-12 bg-[#0a0f1c] border border-white/10 rounded-2xl p-6">
                        <div className="flex items-center gap-3 mb-5">
                          <div className="p-1.5 rounded-md bg-primary/20 text-primary">
                            <Network className="w-4 h-4" />
                          </div>
                          <h3 className="text-lg font-display font-semibold text-white">Identified Competitors / Prior Art</h3>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {data.similarIdeas.map((similar, idx) => (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.4 + (idx * 0.05) }}
                              key={idx}
                              className="px-3 py-1.5 rounded-md bg-white/5 border border-white/10 text-white/70 text-xs font-medium hover:bg-white/10 transition-colors cursor-default"
                            >
                              {similar}
                            </motion.div>
                          ))}
                          {data.similarIdeas.length === 0 && (
                            <p className="text-white/40 italic text-sm">No direct competitors found in market analysis.</p>
                          )}
                        </div>
                      </div>

                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 6) IMPACT METRICS */}
        <section id="impact" className="py-24 px-4 bg-primary/5 border-y border-primary/10 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,183,255,0.1)_0%,transparent_70%)]" />
          <div className="max-w-7xl mx-auto relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Built for Speed & Scale</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { metric: "99%", label: "Faster than manual validation", color: "from-blue-400 to-primary" },
                { metric: "Minutes", label: "Instead of weeks of research", color: "from-purple-400 to-accent" },
                { metric: "6 Agents", label: "Multi-agent decision intelligence", color: "from-emerald-400 to-teal-500" },
                { metric: "Enterprise", label: "Ready for production workflows", color: "from-amber-400 to-orange-500" }
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="text-center p-6"
                >
                  <div className={cn(
                    "text-5xl lg:text-6xl font-black font-display mb-4 text-transparent bg-clip-text bg-gradient-to-br",
                    stat.color
                  )}>
                    {stat.metric}
                  </div>
                  <div className="text-white/70 font-medium text-lg">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 7) WHO IS THIS FOR */}
        <section className="py-24 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-4">Built For</h2>
            </div>
            
            <div className="flex flex-wrap justify-center gap-4 md:gap-6">
              {[
                { icon: Rocket, title: "Startups", desc: "Pivot faster before burning runway." },
                { icon: GraduationCap, title: "Students", desc: "Validate thesis and capstone ideas." },
                { icon: Lightbulb, title: "Innovators", desc: "Test side projects instantly." },
                { icon: Building2, title: "Enterprises", desc: "Filter internal innovation labs." },
                { icon: Briefcase, title: "Incubators", desc: "Screen applicant cohorts automatically." }
              ].map((audience, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="w-full sm:w-[calc(50%-12px)] md:w-[calc(33.333%-16px)] lg:w-[calc(20%-20px)] glass-panel p-6 rounded-2xl flex flex-col items-center text-center hover:bg-white/10 transition-colors cursor-default"
                >
                  <audience.icon className="w-8 h-8 text-white/50 mb-4" />
                  <h3 className="text-lg font-bold mb-2">{audience.title}</h3>
                  <p className="text-sm text-white/50 leading-tight">{audience.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* 8) FOOTER */}
      <footer className="border-t border-white/5 bg-[#02050a] py-12 px-4 relative z-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-lg font-display font-bold">
            <Sparkles className="w-4 h-4 text-primary" />
            <span>InnoCheck <span className="text-white/50">Enterprise</span></span>
          </div>
          
          <div className="text-white/40 text-sm text-center">
            &copy; {new Date().getFullYear()} InnoCheck AI. All rights reserved.
          </div>
          
          <div className="text-white/40 text-sm text-center md:text-right flex flex-col gap-1">
            <span className="font-medium text-white/60">Team Code GPT</span>
            <span>SAL Institute of Technology and Engineering Research</span>
            <span>Hackathon Prototype 2026</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
