import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface ScoreRingProps {
  score: number;
}

export function ScoreRing({ score }: ScoreRingProps) {
  const [currentScore, setCurrentScore] = useState(0);
  const size = 180;
  const strokeWidth = 12;
  const center = size / 2;
  const radius = center - strokeWidth;
  const circumference = 2 * Math.PI * radius;
  
  // Animation for the number counting up
  useEffect(() => {
    let start = 0;
    const end = score;
    if (start === end) return;
    
    const duration = 1500; // ms
    const incrementTime = 20;
    const steps = Math.abs(Math.floor(duration / incrementTime));
    const stepValue = (end - start) / steps;
    
    const timer = setInterval(() => {
      start += stepValue;
      if ((stepValue > 0 && start >= end) || (stepValue < 0 && start <= end)) {
        setCurrentScore(end);
        clearInterval(timer);
      } else {
        setCurrentScore(Math.floor(start));
      }
    }, incrementTime);
    
    return () => clearInterval(timer);
  }, [score]);

  // Determine color based on score
  const getColorClass = () => {
    if (score >= 80) return "text-emerald-400";
    if (score >= 50) return "text-amber-400";
    return "text-rose-400";
  };

  const getStrokeColor = () => {
    if (score >= 80) return "#34d399"; // emerald-400
    if (score >= 50) return "#fbbf24"; // amber-400
    return "#fb7185"; // rose-400
  };

  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Background Track */}
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="transparent"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-white/5"
        />
        {/* Animated Progress */}
        <motion.circle
          cx={center}
          cy={center}
          r={radius}
          fill="transparent"
          stroke={getStrokeColor()}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]"
        />
      </svg>
      
      <div className="absolute flex flex-col items-center justify-center text-center">
        <span className={`text-5xl font-display font-bold tracking-tighter ${getColorClass()}`}>
          {currentScore}
        </span>
        <span className="text-xs font-medium uppercase tracking-widest text-muted-foreground mt-1">
          Novelty
        </span>
      </div>
    </div>
  );
}
