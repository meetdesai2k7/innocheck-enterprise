import { Router, type IRouter } from "express";
import healthRouter from "./health";
import analyzeRouter from "./analyze";

const router: IRouter = Router();

// Mount health check route
router.use(healthRouter);

// Mount idea analysis route
router.use(analyzeRouter);

export default router;
