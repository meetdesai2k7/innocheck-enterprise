import { Router, type IRouter } from "express";
import { AnalyzeIdeaBody, AnalyzeIdeaResponse } from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

// POST /api/analyze - accepts an idea and returns structured AI analysis
router.post("/analyze", async (req, res) => {
  try {
    // Validate the request body using generated Zod schema
    const parseResult = AnalyzeIdeaBody.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({ error: "Invalid request: 'idea' field is required." });
      return;
    }

    const { idea } = parseResult.data;

    if (!idea || idea.trim().length === 0) {
      res.status(400).json({ error: "Idea cannot be empty." });
      return;
    }

    // Build the prompt for structured analysis
    const prompt = `You are an expert innovation mentor.
Analyze the following idea and respond ONLY with a valid JSON object in exactly this format:
{
  "noveltyScore": <number 0-100>,
  "similarIdeas": [<string>, <string>, ...],
  "strengths": [<string>, <string>, ...],
  "weaknesses": [<string>, <string>, ...],
  "improvedIdea": "<string>"
}

Rules:
- noveltyScore: integer from 0 to 100
- similarIdeas: 2-4 existing products or concepts that are similar
- strengths: 3-5 key strengths or advantages
- weaknesses: 3-5 key weaknesses or challenges
- improvedIdea: a refined, enhanced version of the idea in 2-4 sentences
- Do NOT include any text outside of the JSON object

Idea: ${idea.trim()}`;

    // Call the OpenAI API with the structured prompt
    const completion = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 8192,
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const rawContent = completion.choices[0]?.message?.content;
    if (!rawContent) {
      req.log.error("OpenAI returned empty response");
      res.status(500).json({ error: "AI returned an empty response. Please try again." });
      return;
    }

    // Parse the JSON response from the AI
    let parsed: unknown;
    try {
      // Strip markdown code fences if present
      const cleaned = rawContent.replace(/^```(?:json)?\n?/m, "").replace(/\n?```$/m, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      req.log.error({ rawContent }, "Failed to parse OpenAI JSON response");
      res.status(500).json({ error: "Failed to parse AI response. Please try again." });
      return;
    }

    // Validate the response shape using generated Zod schema
    const validated = AnalyzeIdeaResponse.safeParse(parsed);
    if (!validated.success) {
      req.log.error({ parsed, errors: validated.error }, "AI response did not match expected schema");
      res.status(500).json({ error: "AI response was malformed. Please try again." });
      return;
    }

    // Return the structured analysis
    res.json(validated.data);
  } catch (err) {
    req.log.error({ err }, "Error analyzing idea");
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

export default router;
